Cabrália Tour
==============

Informações turísticas de Santa Cruz Cabrália-BA

App desenvolvido pelo CEIT-PR3G de Santa Cruz Cabrália, sob orientação e supervisão da equipe de desenvolvimento da Telefônica/Vivo e da Editacuja.

Projeto desenvolvido para o plataforma Mozilla Firefox OS, utilizando os componentes Building Blocks [buildingfirefoxos.com](http://www.buildingfirefoxos.com).

Cross browser support
-----------------------
Include `cross_browser.css` if you want your webapp can run on any modern browser.
Please test your app in your target browsers, as "style" folder is pulled automatically from the original source, if some styles changes before we have the change to update this file, we cannot guarantee it will always work as expected.
